% This script is part of the MATLAB workflow for the population balance
% modeling of C-S-H precipitation. The system is described in the following article:
% Andalibi, M. Reza, et al. "On the mesoscale mechanism of synthetic calcium?silicate?hydrate precipitation:
% a population balance modeling approach." 
% Journal of Materials Chemistry A 6.2 (2018): 363-373.
%
% Please cite our article:
% Andalibi, M. R., et al. (2019). Global uncertainty-sensitivity analysis on mechanistic kinetic models: 
% from model assessment to theory-driven design of nanoparticles."

%% Add the folder containing the PBE workflow to the working directory 
% addpath(genpath('D:\Dropbox\PBE_wokflow_for_publication'));

%% Set up the definition of the experimental system and thermodynamic properties
% Experimental system: C-S-H precipitation in semi-batch reactor, adding Na2SiO3+NaOH to Ca(NO3)2

% List of species, and other thermodynamic information------------------------------------------------------------------%
% List of elements including those not initially in the system but added later, for example to keep pH constant 
% (e.g., if NaOH is not present initially but is added during the raeaction to regulate pH)
elements = {'Ca','Si','Na','N','Ntg'};
% List of aqueous species (those in which we're interested) compatible with database used in PHREEQC
aqSpecies = ...
    {'OH-','H+','Ca+2','Ca(OH)+','CaSiO3','Ca(HSiO3)+',...
    'HSiO3-','SiO3-2','SiO2','Si4O10-4','Na+','NaOH','NO3-','Ntg'};
% List of gaseous species with known partial pressures
gasSpecies = {'Ntg(g)'};
% A flag with ones in the first row denoting the elements that have to be equilibrated forcing 
% desired partial pressure of the gas with the corresponding index in the second row
elements_gasEquilFlag = [0,0,0,0,1; 0,0,0,0,1];
% List of solid species; at the moment only the FIRST one can be precipitated in the kinetic code
solidSpecies = {'CSH','Portlandite'};
% Index of solid phases not already in the thermodynamic database and/or defined by the user; 
% the precipitating solid has to be the first solid
solidDefInd = 1;

% Inputs for defining the added solid phase
% Dissolution reaction
dissRxn_precSolid = {'(CaO)1.0(SiO2)0.5(H2O)1.5 = Ca(OH)+ + 0.5HSiO3- + 0.5OH- + 0.5H2O'};
% Molar volume
molarVol_precSolid = 49.20e-6; % m3/mol
% log10 of equilibrium constant for the dissolution reaction above
logK_precSolid = -7.21958906895829;
% Enthalpy change of dissolution reaction above (J/mol)
delta_h_precSolid = 14850;

% Experimental conditions (concentrations, volumes, flow rate, etc)-----------------------------------------------------%
% Initial volumes and concentration are reported at room T
T = 25; % Experimental temperature ('C)
% Elements initially in the reactor, rxt, (mol/kg H2O or approximately mol/L for dilute solutions); 
% for elements only related to a gas phase (like Ntg) put zero because the amount is calculated by fixing 
% the partial pressure
element_rxtConc = [0.02,0,0,0.04,0];
% Elements added to the reactor with the inflow (mol/kgw molality in the stream)
element_inflowConc = [0,9e-3,0.117,0,0];
% log10 of partial pressures for the gas phase species (vector for multiple gases)
gasSI = 0;
% Initial volume of solution inside the reactor (m3)
V0_rxt = 0.2e-3;
% Total volume of the inflow solution to be added (m3)
V0_inflow = 0.222e-3;
% Flow rate of the inflow stream (m3/s)
Q_inflow = 0.5e-6/60;
% Leave empty if pH is not fixed; give a pH value if fixed
set_pH = [];
% The name of compound used to keep the pH constant; all the elements of this species have to be present in "elements"
fixed_pH_Compound = 'NaOH';
% Atom symbol of the ion of pH-fixing compound the amount of which has to be adjusted (by charge balance) to attain 
% fixed pH; has to be present in "elements"
fixed_pH_Elem = 'Na';

%% Setup kinetic parameters
gamma = 55e-3; % Interfacial tension (J/m2)
sigmaRel = 45e-3/55e-3; % Relative cohesion energy (cohesion energy/interfacial tension)
k_r = 2.5e-9; % Growth rate coefficient (SI units)
g = 2; % Kinetic order of growth
a_r = 0.5; % Edge length to thickness ratio for crystallites (cuboid shaped)

stoich_precSolid = [1,0.5,0,0,0]; % Stoichiometry of elements in the precipitating solid
nuPrecSolid = 2; % Sum of stoichiometric coefficients for species forming by dissolution (except for water)

% Time steps and, if applicable, experimental data------------------------%
tOutput = [(0:60:3600*4-60),(3600*4:600:3600*12)]'; % time (s)

%% Load thermodynamic database
iphreeqc = actxserver('IPhreeqcCOM.Object');
iphreeqc.LoadDatabase([pwd,'\CEMDATA18_modified.dat']); % CEMDATA18 with the necessary species for this problem (shortened to expedite the simulations)

%% Run PBE simulations
% Toggle warning messages on/off (they can impede runtimes)
% warning('off','MATLAB:nearlySingularMatrix')
% warning('on','MATLAB:nearlySingularMatrix')

warning('on','all')

tic
[nParticle,quadPoints,moments,elementConc_balanced] = pbe(tOutput,iphreeqc,elements,aqSpecies,gasSpecies,elements_gasEquilFlag,solidSpecies,solidDefInd,...
    dissRxn_precSolid,molarVol_precSolid,logK_precSolid,delta_h_precSolid,stoich_precSolid,nuPrecSolid,...
    T,element_rxtConc,element_inflowConc,gasSI,V0_rxt,V0_inflow,Q_inflow,set_pH,fixed_pH_Compound,fixed_pH_Elem,gamma,sigmaRel,k_r,g,a_r);
toc

%% Some auxiliary outputs
% Volume of reaction liquor
V_rxt = V0_rxt + Q_inflow*tOutput;
V_rxt(V_rxt>V0_rxt+V0_inflow) = V0_rxt+V0_inflow;

% Mole amount C-S-H formed as a function of time
molCSH = 1000*V0_rxt*element_rxtConc(1)-elementConc_balanced(:,1).*V_rxt*1000;

% Equilibrium amount of C-S-H that can precipitate (maximum possible)
% Mixture amounts of different elements
elementConc_mix = (V0_rxt*element_rxtConc + min(V0_inflow, Q_inflow*tOutput)*...
    element_inflowConc)./(V0_rxt + min(V0_inflow, Q_inflow*tOutput));
elementConc_FullYield = zeros(length(tOutput),length(elements)); % Element concentrations if at time step full yield (equilibrium) is achieved
molCSH_SLE = zeros(length(tOutput),1);
parfor ii=1:length(tOutput)
    % Load database
    iphreeqc = actxserver('IPhreeqcCOM.Object');
    iphreeqc.LoadDatabase([pwd, '\CEMDATA18_modified.dat']);
    % Local equilibrium
    [water_kg,~,elementConc_FullYield_Temp,~,~,~,~,~,~] = ...
        eqbrmSolver(iphreeqc,elements,aqSpecies,gasSpecies,elements_gasEquilFlag,solidSpecies,solidDefInd,...
        1,dissRxn_precSolid,molarVol_precSolid,logK_precSolid,delta_h_precSolid,...
        T,(V0_rxt+min(V0_inflow,Q_inflow*tOutput(ii)))*1000,[elementConc_mix(ii,:),0],gasSI,set_pH,fixed_pH_Compound,fixed_pH_Elem);
    molCSH_SLE(ii) = 1000*V0_rxt*element_rxtConc(1)-elementConc_FullYield_Temp(2,1)*water_kg(2); % mol
    elementConc_FullYield(ii,:) = elementConc_FullYield_Temp(2,:);
end
clear elementConc_FullYield_Temp water_kg

MW_CSH = 113.1400; % Molecular wight of solid (g/mol)
crystL = (moments(:,4)./moments(:,1)).^(1/3)*1e9;
kV = a_r.^2; % Crystallite volume shape factor
kA = 2*a_r.*(a_r + 2);  % Crystallite surface area shape factor
partL = crystL.*sqrt(kV.*moments(:,1)./nParticle); % nm
% Crystallite and particle specific surface areas (m2/g solid)
crystSSA = moments(:,1).*kA.*crystL.^2*1e-18*(V0_rxt+V0_inflow)./molCSH/MW_CSH;
partSSA = nParticle*(V0_rxt+V0_inflow).*(2*partL.^2+4*crystL.*partL)*1e-18./molCSH/MW_CSH;

% Kinetic speciation: CSH and Portlandite SI + Critical size of primary and secondary nuclei
cshSI = zeros(length(tOutput),1);
pH = zeros(length(tOutput),1);
ionicStr = zeros(length(tOutput),1);
speciesConc = zeros(length(tOutput),length(aqSpecies));
portlanditeSI = zeros(length(tOutput),1);
V_rxt = V0_rxt+Q_inflow*tOutput;
V_rxt(V_rxt>V0_rxt+V0_inflow) = V0_rxt+V0_inflow;
tic
parfor ii=1:length(tOutput)
    % Load database
    iphreeqc = actxserver('IPhreeqcCOM.Object');
    iphreeqc.LoadDatabase([pwd, '\CEMDATA18_modified.dat']);
    % Local equilibrium
    [~,~,~,speciesConc(ii,:),~,saturationInd,pH(ii,:),ionicStr(ii,:),~] = ...
            eqbrmSolver(iphreeqc,elements,aqSpecies,gasSpecies,elements_gasEquilFlag,solidSpecies,solidDefInd,...
            0,dissRxn_precSolid,molarVol_precSolid,logK_precSolid,delta_h_precSolid,...
            T,V_rxt(ii)*1000,[elementConc_balanced(ii,:),0],gasSI,set_pH,fixed_pH_Compound,fixed_pH_Elem);
        cshSI(ii) = saturationInd(1);
        portlanditeSI(ii) = saturationInd(2);
end
clear saturationInd
toc

N_A = 6.0221409e+23; % Avogadro constant
kB = 1.38064852e-23; % Boltzmann constant (J/K)
monomerVol = molarVol_precSolid/N_A; % m3
gammaEff = gamma-sigmaRel*gamma/2/(a_r+2);
LI = 1e9*2*kA*monomerVol.*gamma/3./kV/kB/(T+273.15)./log(10.^cshSI);
LII = 1e9*2*kA*monomerVol.*gammaEff/3./kV/kB/(T+273.15)./log(10.^cshSI);

%% Plot outputs
% Check the dependent variables of ODE 
figure('Color','White')
subplot(2,3,1)%----------------------------------------------------------%
semilogy(tOutput/3600,moments(:,1),'ro')
xlabel('time (h)')
ylabel('m_{0}')
set(gca,'FontSize',16,'FontWeight','bold')
axis square
subplot(2,3,2)%----------------------------------------------------------%
yyaxis left
plot(tOutput/3600,crystL,'o')
xlabel('time (h)')
ylabel('L_{cryst} (nm)')
yyaxis right
plot(tOutput/3600,partL,'s')
ylabel('L_{part} (nm)')
set(gca,'FontSize',16,'FontWeight','bold')
axis square
subplot(2,3,3)%----------------------------------------------------------%
semilogy(tOutput/3600,quadPoints(:,1:3),'o')
xlabel('time (h)')
ylabel('w_{\alpha} (m^{-3})')
ylim([0,10^(ceil((max(max(log10(quadPoints(:,1:3))))))+2)])
set(gca,'FontSize',16,'FontWeight','bold')
axis square
subplot(2,3,4)%----------------------------------------------------------%
plot(tOutput/3600,quadPoints(:,4:6)*1e9,'o')
xlabel('time (h)')
ylabel('L_{\alpha} (nm)')
set(gca,'FontSize',16,'FontWeight','bold')
axis square
subplot(2,3,5)%----------------------------------------------------------%
plot(tOutput/3600,elementConc_balanced(:,1)*1e3,'bo'); hold on
plot(tOutput/3600,elementConc_balanced(:,2)*1e3,'rs'); hold on
plot(tOutput/3600,elementConc_FullYield(:,1)*1e3,'b--','lineWidth',1.5); hold on
plot(tOutput/3600,elementConc_FullYield(:,2)*1e3,'r--','lineWidth',1.5);
xlabel('time (h)')
ylabel({'Concentration', '(mmol/kg Water)'})
legend({'Ca (aq)','Si(aq)'})
set(gca,'FontSize',16,'FontWeight','bold')
axis square
subplot(2,3,6)%----------------------------------------------------------%
plot(tOutput/3600,elementConc_balanced(:,3)*1e3,'bo'); hold on
plot(tOutput/3600,elementConc_balanced(:,4)*1e3,'rs'); hold on
plot(tOutput/3600,elementConc_FullYield(:,3)*1e3,'b--','lineWidth',1.5); hold on
plot(tOutput/3600,elementConc_FullYield(:,4)*1e3,'r--','lineWidth',1.5);
xlabel('time (h)')
ylabel({'Concentration', '(mmol/kg Water)'})
legend({'Na (aq)','N(aq)'})
set(gca,'FontSize',16,'FontWeight','bold')
axis square
maximize

% Kinetic speciation
figure('Color','White')
subplot(2,2,1)%----------------------------------------------------------%
plot(tOutput/3600,1e3*molCSH,'kx',tOutput/3600,1e3*molCSH_SLE,'r--','linewidth',1.5)
xlabel('time (h)')
ylabel('C-S-H amount (mmol)')
legend({'Kinetic','SLE'},'location','southeast')
axis square
set(gca,'fontsize',18,'fontweight','bold')
subplot(2,2,2)%----------------------------------------------------------%
yyaxis left
plot(tOutput/3600,pH,'x','linewidth',1.5,'markersize',7)
xlabel('time (h)')
ylabel('pH')
yyaxis right
plot(tOutput/3600,ionicStr*1e3,'s','linewidth',1.5,'markersize',7)
ylabel({'Ionic strengh ','(mmol/kg Water)'})
axis square
set(gca,'fontsize',18,'fontweight','bold')
subplot(2,2,3)%----------------------------------------------------------%
plot(tOutput/3600,speciesConc(:,3:6)*1e3,'linewidth',1.5)
xlabel('time (h)')
ylabel({'Concentration','(mmol/kg Water)'})
axis square
set(gca,'fontsize',18,'fontweight','bold')
legend(aqSpecies(3:6))
subplot(2,2,4)%----------------------------------------------------------%
plot(tOutput/3600,speciesConc(:,5:10)*1e3,'linewidth',1.5)
xlabel('time (h)')
ylabel({'Concentration','(mmol/kg Water)'})
axis square
set(gca,'fontsize',18,'fontweight','bold')
legend(aqSpecies(5:10))
maximize

% Supersaturation ratios and critical nucleus sizes
figure('Color','White')
subplot(1,2,1)
plot(tOutput/3600,10.^cshSI,'g-',tOutput/3600,10.^portlanditeSI,'r.','MarkerSize',20,'LineWidth',3); hold on
plot(tOutput/3600,ones(length(tOutput),1),'k--','LineWidth',2)
xlabel('time (h)')
ylabel({'Supersaturation ratio',' (IAP/K_{sp})'})
legend({'C-S-H', 'Portlandite'})
axis square
set(gca,'FontSize',24,'FontWeight','bold')
subplot(1,2,2)
plot(tOutput/3600,LI,'k.',tOutput/3600,LII,'r.','LineWidth',1.5)
xlabel('time (h)')
ylabel('Critical nucleus size (nm)')
legend({'L_{I}','L_{II}'})
ylim([0,ceil(crystL(end))])
set(gca,'FontSize',24,'FontWeight','bold')
axis square
maximize
