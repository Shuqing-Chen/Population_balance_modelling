function [water_kg,solutionDensity,elementConc,speciesConc,speciesAct,saturationInd,pH,ionicStr,out_PHREEQC_headers] = ...
    eqbrmSolver(iphreeqc,elements,aqSpecies,gasSpecies,elements_gasEquilFlag,solidSpecies,solidDefInd,...
    SLE_flag,solidDissRxn,solidMolarVol,logK_solid,delta_h_solid,...
    T,water_kg_input,elementConc_input,gasSI,set_pH,fixed_pH_Compound,fixed_pH_Elem)
% This function provides an interface with Phreeqc via IPhreeqc COM object for the calculation of aqueous or solid-liquid equilibria
% 
% Input:
% iphreeqc = IPhreeqc COM object activated by "actxserver('IPhreeqcCOM.Object')"; will be activated within the function if not provided (consider providing for speed up)
% elements = List of elements including those not initially in the system but added later, for example to keep pH constant (e.g., if NaOH is not present initially but is added during the raeaction to regulate pH)
% aqSpecies = List of aqueous species (those in which we're interested) compatible with the database used in PHREEQC (loaded by "iphreeqc.LoadDatabase([pwd,'\CEMDATA18_modified.dat']);")
% gasSpecies = List of gaseous species with known partial pressures
% elements_gasEquilFlag = A flag with ones in the first row denoting the elements that have to be equilibrated forcing the desired partial pressure of the gas with the corresponding index in the second row
% solidSpecies = List of solid species; at the moment only the FIRST one can be precipitated in the kinetic code
% solidDefInd = Index of solid phases not already in the thermodynamic database; the precipitating solid has to be the first solid for the kinetic code
% SLE_flag = Flag with one indicating solid-liquid equilibrium is saught for with respect to the solid of the corresponding index
% solidDissRxn = Dissolution reaction for the solid to be defined
% solidMolarVol = Molar volume for the solid to be defined
% logK_solid = log10 of equilibrium constant for the dissolution reaction above (for the solid to be defined)
% delta_h_solid = Enthalpy change of dissolution reaction above (J/mol) (for the solid to be defined)
% T = Experimental temperature ('C)
% water_kg_input = Mass of water solvent (kg)
% elementConc_input = Total concentration of different elements (mol/kg H2O or approximately mol/L for dilute solutions)
% gasSI = log10 of partial pressures for the gas phase species (vector for multiple gases)
% set_pH = Leave empty ([]) if pH is not fixed; give a pH value if fixed
% fixed_pH_Compound = The name of compound used to keep the pH constant; all the elements of this species have to be present in "elements"
% fixed_pH_Elem = Atom symbol of the ion of pH-fixing compound the amount of which has to be adjusted (by charge balance) to attain fixed pH; has to be present in "elements"
% 
% Output:
% water_kg = Mass of water solvent (kg) after equilibrium calculations
% solutionDensity = Density of solution (g/cm3) after equilibrium calculations
% elementConc = Concentrations of aqueous elements (mol/kg H2O) after equilibrium calculations
% speciesConc = Concentrations of aqueous species (mol/kg H2O) after equilibrium calculations
% speciesAct = Activities of aqueous species (mol/kg H2O) after equilibrium calculations
% saturationInd = Saturation indices (log10(IAP/K_sp)) after equilibrium calculations
% pH = pH of solution after equilibrium calculations
% ionicStr = Ionic strength of the solution (mol/kg H2O) after equilibrium calculations
% out_PHREEQC_headers = header of the output from Phreeqc
% 
% This function is part of the MATLAB workflow for the population balance
% modeling of C-S-H precipitation. The system is described in the following article:
% Andalibi, M. Reza, et al. "On the mesoscale mechanism of synthetic calcium?silicate?hydrate precipitation:
% a population balance modeling approach." 
% Journal of Materials Chemistry A 6.2 (2018): 363-373.
%
% Please cite our article:
% Andalibi, M. R., et al. (2019). Global uncertainty-sensitivity analysis on mechanistic kinetic models: 
% from model assessment to theory-driven design of nanoparticles."

% Initialize the cell array (headers in the Phreeqc output cell array)
out_PHREEQC_headers = {};

% Load the database for the equilibrium solver (if not provided as input)
if isempty(iphreeqc)
    iphreeqc = actxserver('IPhreeqcCOM.Object');
    if iphreeqc.LoadDatabase('C:\Users\andalibi_m\Dropbox\CSH_UA_SA\CEMDATA18_modified.dat') == 0
        fprintf('Database checked and loaded\n')
    else
        fprintf('Database contains errors\n')
    end
end

% Clear the history of commands in Phreeqc
iphreeqc.ClearAccumulatedLines();

% Reduce the step size to avoid convergence problems
iphreeqc.AccumulateLine('KNOBS');
iphreeqc.AccumulateLine('-step_size 3');

% Define the phases
iphreeqc.AccumulateLine('PHASES');

% Fictitious pH fixing mineral (pH = -SI)
if ~isempty(set_pH)
    iphreeqc.AccumulateLine('Fix_pH');
    iphreeqc.AccumulateLine('H+ = H+');
    iphreeqc.AccumulateLine('log_k 0.0');
end

% Solid phases not present in the database
if ~isempty(solidDefInd)
    for ii=1:length(solidDefInd)
        iphreeqc.AccumulateLine(solidSpecies{solidDefInd(ii)}); % Ca:Si=2 from CSHQ model of Kulik, 2011
        iphreeqc.AccumulateLine(solidDissRxn{ii,:});
        iphreeqc.AccumulateLine(['-Vm ', num2str(solidMolarVol(ii)*1e6)]); % Vm in Phreeqc is in cm3/mol
        iphreeqc.AccumulateLine(['-log_k ', num2str(logK_solid(ii))]);
        iphreeqc.AccumulateLine(['-delta_h ', num2str(delta_h_solid(ii)), ' J/mol']);
    end
end

% Define the solution inside the reactor to be equilibrated (either local equilibrium of SLE)
iphreeqc.AccumulateLine('SOLUTION');
iphreeqc.AccumulateLine(['temp ', num2str(T)]);
iphreeqc.AccumulateLine('units mol/kgw');
iphreeqc.AccumulateLine('density 1 calculate');
iphreeqc.AccumulateLine(['-water ', num2str(water_kg_input)]);
for ii=1:length(elements)
    if elements_gasEquilFlag(1,ii)==0
        iphreeqc.AccumulateLine([elements{ii}, ' ', num2str(elementConc_input(ii))]);
    else
        iphreeqc.AccumulateLine([elements{ii}, ' 10 ', gasSpecies{elements_gasEquilFlag(2,ii)},...
            ' ', num2str(gasSI(elements_gasEquilFlag(2,ii)))]);
    end
end
if isempty(set_pH)
    iphreeqc.AccumulateLine('pH 7 charge');
else
    iphreeqc.AccumulateLine(['pH 7 Fix_pH ', num2str(-set_pH)]);
    iphreeqc.AccumulateLine([fixed_pH_Elem, ' 1e-16 charge']);
end

% If solid-liquid equilibrium is saught for
if SLE_flag==1
    iphreeqc.AccumulateLine('EQUILIBRIUM_PHASES');
    if ~isempty(set_pH)
        iphreeqc.AccumulateLine(['Fix_pH ', num2str(-set_pH), ' ', fixed_pH_Compound, ' 10']);
    end
    % Equilibrate the gas phases
    for ii=1:length(gasSpecies)
        iphreeqc.AccumulateLine([gasSpecies{ii}, ' ', num2str(gasSI(ii)), ' 10']);
    end
    % Equilibrate solid phases
    for ii=1:length(solidSpecies)
        iphreeqc.AccumulateLine([solidSpecies{ii}, ' 0.0 0.0']);
    end
end

% What PHREEQC outputs should be retrieved
iphreeqc.AccumulateLine ('SELECTED_OUTPUT');
iphreeqc.AccumulateLine('-simulation false');
iphreeqc.AccumulateLine('-state false');
iphreeqc.AccumulateLine('-solution false');
iphreeqc.AccumulateLine('-distance false');
iphreeqc.AccumulateLine('-time false');
iphreeqc.AccumulateLine('-step false');
iphreeqc.AccumulateLine('-pH true');
iphreeqc.AccumulateLine('-pe false');
iphreeqc.AccumulateLine('-reaction false');
iphreeqc.AccumulateLine('-temperature false');
iphreeqc.AccumulateLine('-alkalinity false');
iphreeqc.AccumulateLine('-ionic_strength true');
iphreeqc.AccumulateLine('-water true');
iphreeqc.AccumulateLine('-charge_balance false');
iphreeqc.AccumulateLine('-percent_error false');
iphreeqc.AccumulateLine(['-totals ', strjoin(elements)]);
iphreeqc.AccumulateLine(['-molalities ', strjoin(aqSpecies)]);
iphreeqc.AccumulateLine(['-activities ', strjoin(aqSpecies)]);
iphreeqc.AccumulateLine(['-saturation_indices ', strjoin(solidSpecies), ' ', strjoin(gasSpecies)]);
iphreeqc.AccumulateLine('USER_PUNCH');
iphreeqc.AccumulateLine('-head rho_kg_per_L');
iphreeqc.AccumulateLine('10 PUNCH RHO');
iphreeqc.AccumulateLine('END');

% Run Phreeqc simulation
if iphreeqc.RunAccumulated == 0
    out_PHREEQC = iphreeqc.GetSelectedOutputArray;
    % Save the header of the output from Phreeqc
    out_PHREEQC_headers = out_PHREEQC(1,:);
    % Convert numeric output to array
    out_PHREEQC = cell2mat(out_PHREEQC(2:end,:));
end

% Assign outputs of the functio
pH = out_PHREEQC(:,1);
ionicStr = out_PHREEQC(:,2);
water_kg = out_PHREEQC(:,3);
elementConc = out_PHREEQC(:,4:3+length(elements));
speciesConc = out_PHREEQC(:,4+length(elements):3+length(elements)+length(aqSpecies));
speciesAct = out_PHREEQC(:,4+length(elements)+length(aqSpecies):3+length(elements)+length(aqSpecies)*2);
saturationInd = out_PHREEQC(:,4+length(elements)+length(aqSpecies)*2:end-1);
solutionDensity = out_PHREEQC(:,end); % g/cm3 or kg/L
