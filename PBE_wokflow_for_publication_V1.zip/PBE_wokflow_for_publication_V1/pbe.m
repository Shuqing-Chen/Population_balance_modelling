function [nParticle,quadPoints,moments,elementConc_balanced] = pbe(tOutput,iphreeqc,elements,aqSpecies,gasSpecies,elements_gasEquilFlag,solidSpecies,solidDefInd,...
    dissRxn_precSolid,molarVol_precSolid,logK_precSolid,delta_h_precSolid,stoich_precSolid,nuPrecSolid,...
    T,element_rxtConc,element_inflowConc,gasSI,V0_rxt,V0_inflow,Q_inflow,set_pH,fixed_pH_Compound,fixed_pH_Elem,gamma,sigmaRel,k_r,g,a_r)
% This function handles the precipitation kinetics (via PBE) for only one solid phase denoted as "precSolid" which should be always the first phase in "solidSpecies" cell array
% 
% Input:
% tOutput = time (s); if no experimental data are available simply provide vector of time steps at which ODE set integration has to return results
% iphreeqc = iphreeqc COM object; providing [] would make the eqbrmSolver to load the object every time it is called
% elements = List of elements including those not originally in the system but added later to keep pH constant (e.g., if NaOH is not present initially but is added during the raeaction to regulate pH)
% aqSpecies = List of aqueous species (those in which we're interested!) compatible with database used with PHREEQC
% gasSpecies = List of gaseous species with known partial pressures
% elements_gasEquilFlag = A flag with nonzero elements in the first row denoting the index of elements in aqElements that have to be added forcing desired partial pressure of the gas with the corresponding index in the second row
% solidSpecies = List of solid species; at the moment only the first one can be precipitated in the kinetic code (multiple solids planned for future)
% solidDefInd = Index of solid phases not already in the thermodynamic database and/or defined by the user
% dissRxn_precSolid = Dissolution reaction for the precipitating solid
% molarVol_precSolid = Molar volume of the precipitating solid
% logK_precSolid = log10 of equilibrium constant for the dissolution of the precipitating solid
% delta_h_precSolid = Enthalpy change for the dissolution reaction of the precipitating solid
% stoich_precSolid = the stoichiometry of elements in the precipitating solid (ordered similar to elements)
% nuPrecSolid = Sum of stoichiometries of aqueous species (water excluded) produced by dissolution of 1 unit cell of precipitating solid
% T = temperature ('C)
% element_rxtConc = Elements initially in the reactor, rxt, (mol/kg H2O or approximately mol/L for dilute solutions); for elements only related to a gas phase (like Ntg) put zero
% element_inflowConc = Elements added to the reactor with the inflow (mol/kgw molality in the stream)
% gasSI = log10 of partial pressures for the gas phase species (vector for multiple gases)
% V0_rxt = initial (before addition of the second reactant) solution volume inside the reactor (m3)
% V0_inflow = total solution volume added to the reactor (m3)
% Q_inflow = addition flow rate (semibatch reactor; m3/s)
% set_pH = pH at which the experiments are done (for pH-stat experiments); leave empty if not fixed; give a number if fixed
% fixed_pH_Compound = The name of compound used to keep the pH constant; all the elements of this species have to be present in "elements"
% fixed_pH_Elem = Atom symbol of the ion of pH-fixing compound the amount of which has to be adjusted (by charge balance) to attain fixed pH; has to be present in "elements"
% gamma = interfacial tension between the solid and the liquid solution (J/m2)
% sigmaRel = cohesion energy between the solid surfaces normalized by gamma (in true catalytic secondary nucleation)
% k_r = linear growth rate coefficient (m^(3g-2).mol^(1-g)/s)
% g = kinetic order of growth (dimensionless)
% a_r = edge-to-thicnkness ratio for cuboid-shaped crystallites (dimensionless)
%
% Output:
% nParticle = number concentration of particles in solution (#/m3 solution; vector) as a function of time
% quadPoints = matrix with quadrature weights (#/m3) and (non-weighted abscissas in m) ordered in columns (each row is a time step)
% moments = moments of crystallite size distribution in SI units
% elementConc_balanced = matrix of elemental concentrations (from mass balance ODEs; mol/kg water) with each column corresponding to one element ordered similar to "elements" (each row is a time step); elements whose amount is dictated by partial pressure of a gas are excluded
% 
% This function is part of the MATLAB workflow for the population balance
% modeling of C-S-H precipitation. The system is described in the following article:
% Andalibi, M. Reza, et al. "On the mesoscale mechanism of synthetic calcium?silicate?hydrate precipitation:
% a population balance modeling approach." 
% Journal of Materials Chemistry A 6.2 (2018): 363-373.
%
% Please cite our article:
% Andalibi, M. R., et al. (2019). "Global uncertainty-sensitivity analysis on mechanistic kinetic models: 
% from model assessment to theory-driven design of nanoparticles."

%% Calculatation/initialization of necessary variables
% Physical constants
kB = 1.38064852e-23; % Boltzmann constant (J/K)
N_A = 6.0221409e+23; % Avogadro constant
% Convert temperature to K
T_K = T+273.15;

% Monomer size and diffusion coefficient
viscWater = exp(-3.7188+578.919/(-137.546+T_K))*1e-3; % dynamic viscosity of water solvent (Pa.s) from Dortmund Databank (DDB)
monomerVol = molarVol_precSolid/N_A; % Volume of monomers/building units of the precipitate (m3)
monomerL = monomerVol^(1/3); % Characteristic length of monomers (m)
solventMolecVol = 3.00e-29; % Molecular volume of solvent (water; m3)
diffCoeff = kB*T_K/(2*pi*viscWater*(monomerVol*6/pi)^(1/3)); % Apparant diffusion coeffiecient from Stokes-Einstein relation (m2/s)

% PBE and DQMOM parameters
qN = 3; % Number of quadrature nodes
kA = 2*a_r*(a_r+2); % Crystallite surface area shape factor (cuboid shaped)
kV = a_r^2; % Crystallite volume shape factor
B = 4*kA^3/27/kV^2; % Crystallite shape factor

% Initial conditions for quadrature weights and weighted abscissas
y0 = zeros(1+2*qN+length(find(~elements_gasEquilFlag(1,:))),1); % ODE dependent variables: number concentration of particles (#/m3), qN quadrature weights, qN quadrature weighted abscissas, and elemental amounts (except those elements the amount of which is dictated by constant partial pressure of a gas)
N0 = 1e2; % Number concentration (#/m3) of crystallites initially in solution; a very small number (compared to typical values in solution) is used rather than zero to prevent numerical problems
L0 = (1:qN)*1e-9; % m; mean size of initial crystallites; a very small number is used rather than zero to prevent numerical problems
y0(1) = log10(N0*qN); % log10(Number concentraation of particles (#/m3))
y0(2:2+qN-1) = log10(N0); % log10(quadrature weights)
y0(2+qN:2*qN+1) = log10(N0*L0*1e+9); % log10(weighted abscissas wi*Li_nm)

% Initial conditions for the mole amounts (in solution) of elements (those for which mass balance will be written, i.e., those not forced by fixed partial pressure of a gas)
y0(2*qN+2:end) = 1e+3*element_rxtConc(elements_gasEquilFlag(1,:)==0)*V0_rxt*1000; % mmol; if working with mol/L the values should be at room tempearture (also the volumes of reactants reported at RT)

%% Integrate the set of ODEs and outputs
% Tolerances for ODE integration; start with the default values and reduce if integration error was not tolerable
% absTol = [1e-7*ones(1+2*qN,1); 1e-7*ones(length(find(~elements_gasEquilFlag(1,:))),1)];
% absTol = [1e-6*ones(1+2*qN,1); 1e-6*ones(length(find(~elements_gasEquilFlag(1,:))),1)];
absTol = [1e-5*ones(1+2*qN,1); 1e-5*ones(length(find(~elements_gasEquilFlag(1,:))),1)];
options = odeset('NonNegative',ones(1+2*qN+length(find(~elements_gasEquilFlag(1,:))),1),...
    'RelTol',1e-12,'AbsTol',absTol); % Add "'OutputFcn',@odeplot" for checking the integration
timeScaleFactor = 1; % Set considering the time scale of processes (e.g., 1e+3 means the time scale is ms)
tOnsetPrecipitation = tOutput(1); % Time at which precipitation starts (to remove fictitious seeds from the output results)
[~,y] = ode15s(@(t,y) odefun(t,y),tOutput*timeScaleFactor,y0,options);

%% Assign the output
nParticle = 10.^y(:,1);
% Correct for when no particle has formed yet (remove fictitious seeds): comment if the process is seeded growth
nParticle(tOutput<tOnsetPrecipitation) = 0;

wi_out = 10.^y(:,2:2+qN-1); % #/m3
Li_out = ( 10.^y(:,2+qN:2*qN+1)./wi_out ) * 1e-9; % m
quadPoints = [wi_out,Li_out];
quadPoints(tOutput<tOnsetPrecipitation,:) = 0;

moments = zeros(length(tOutput),2*qN);
mom_k = repmat((0:2*qN-1)',1,qN); % Column vector with possilbe moment orders [0; 1; 2; ...; 2*qN]
for ii=1:length(tOutput)
    moments(ii,:) = (sum(quadPoints(ii,1:qN).*(quadPoints(ii,1+qN:2*qN).^mom_k),2))';
end
moments(tOutput<tOnsetPrecipitation,:) = 0;

water_kg_Output = (V0_rxt + tOutput*Q_inflow)*1000;
water_kg_Output(water_kg_Output>(V0_rxt+V0_inflow)*1000) = (V0_rxt+V0_inflow)*1000;
elementConc_balanced = y(:,2*qN+2:end)*1e-3./water_kg_Output; % mol/kgw

%% Nested function: ODE set (PBE and mass balances)
    function dydt = odefun(t,y) % nParticle, quadrature wieghts and weighted abscissas (abscissas in nm) are solved after log10 transformation; elemental amounts are in mmol/kg Water
        t = t/timeScaleFactor;
        % Anti-log to get nParticle
        y(1) = 10^y(1);
        
        % Convert mmol to mol for the amounts of the elements
        y(2*qN+2:end) = y(2*qN+2:end)*1e-3;
        
        % Initialize the dydt vector
        dydt = zeros(1+2*qN+length(find(~elements_gasEquilFlag(1,:))),1);
        
        % Mass of water as a function of time
        Q_Current = Q_inflow; % Current flow rate (becomes zero after we run out of the inflow solution)
        water_kg_input = (V0_rxt + t*Q_inflow)*1000;
        if water_kg_input>(V0_rxt+V0_inflow)*1000 % Correct for limited volume added
            Q_Current = 0;
            water_kg_input = (V0_rxt+V0_inflow)*1000;
        end
        
        % Elemental concentrations from the previous time step (those from mass balance + zeros for elements dictated by a fixed gas partial pressure)
        elementConc_input = [y(2*qN+2:end);zeros(1,length(find(elements_gasEquilFlag(1,:))))]/water_kg_input; % mol/kgw
        
        % Local equilibrium assumption: equilibrium speciation among aqueous species is reached at every time step
        [~,solutionDensity,~,~,~,saturationInd,~,~,~] = ...
            eqbrmSolver(iphreeqc,elements,aqSpecies,gasSpecies,elements_gasEquilFlag,solidSpecies,solidDefInd,...
            0,dissRxn_precSolid,molarVol_precSolid,logK_precSolid,delta_h_precSolid,...
            T,water_kg_input,elementConc_input',gasSI,set_pH,fixed_pH_Compound,fixed_pH_Elem);
        supersatRatio = 10^saturationInd(1); % Convert Phreeqc's saturation index to supersaturation ratio
        
        % Extract weights and calculate abscissas from weighted abscissas
        wi = 10.^y(2:2+qN-1); % #/m3
        Li_nm = 10.^y(2+qN:2*qN+1)./wi; % nm
        Li = Li_nm*1e-9; % m
        
        % Construct the A matrix (coefficient matrix for the set of linear equations giving a_i and b_i terms)
        k_Moments = repmat((0:2*qN-1)',1,qN); % Column vector with possilbe moment orders
        A1 = (1-k_Moments).*Li_nm'.^k_Moments; % Without scaling
        A2 = k_Moments.*Li_nm'.^(k_Moments-1); % Without scaling
        
        % Preconditioner matrix
        scaleMatrix = diag(2./(mean(Li_nm).^(0:2*qN-1)' + mean(Li_nm).^(-1:2*qN-2)'));
        
        A_scaled = scaleMatrix*[A1,A2]; % Scaled
        
        % Calculate the first 2*qN moments from weights and weighted abscissas
        m_k = sum(wi'.*(Li'.^k_Moments),2);
        
        % Source term for the changes in the system volume
        V_soln = water_kg_input/solutionDensity/1000; % Solution volume (m3)
        sourceVolChange = -Q_Current/V_soln * m_k .* 10.^(9*(0:2*qN-1)');
        
        % Constructung the odefun output; only one solid (which should be the first one) can be precipitated
        if saturationInd(1)<=log10(1+eps) % No precipitation (not supersaturated enough)
            dydt(1) = -Q_Current/V_soln/log(10); % Time-derivative for number concentration of particles (#/m3)
            
            % Time-derivative for weights and weighted abscissas
            sourceScaled = scaleMatrix*sourceVolChange;
            dydt(2:2*qN+1) = A_scaled\sourceScaled; % Derivative for weights and weighted absiccases (wi*Li_nm)
            dydt(2:2+qN-1) = dydt(2:2+qN-1)/log(10)./wi; % Derivative of log10(wi)
            dydt(2+qN:2*qN+1) = dydt(2+qN:2*qN+1)/log(10)./wi./Li_nm; % Derivative for log10(wi*Li_nm)
            
            % Input flow of elements as the source of change
            dydt(2*qN+2:end) = 1e+3*element_inflowConc(elements_gasEquilFlag(1,:)==0)'*Q_Current*1000; % mmol/s (factor 1000 converts mole/L to mol/m3)
        else
            if tOnsetPrecipitation == tOutput(1)
                tOnsetPrecipitation = t;
            end
            % Approximate solubility of solid (mol/m3); assuming the mass of solutes is negligible compared to the solvent
            cEqbrm = (10^(logK_precSolid - delta_h_precSolid*(1/T_K-1/298.15)/log(10)/kB/N_A))^(1/nuPrecSolid)...
                *1000*solutionDensity;
            
            % Critical size of primary nuclei and primary nucleation rate
            AI = diffCoeff*sqrt((kB*T_K/gamma)^3/(3*pi*B))/monomerL^5/solventMolecVol; % Primary nucleation pre-exponential term; # nuclei/(m3 solution*s)
            LI = 2*kA*monomerVol*gamma/3/kV/kB/T_K/log(supersatRatio); % m
            JI = AI*(log(supersatRatio))^2*exp(-B*gamma^3*monomerVol^2/kB^3/T_K^3/(log(supersatRatio))^2); % #/(m3*s)
            
            % dydt for nParticle
            dydt(1) = (-y(1)*Q_Current/V_soln + JI)/log(10)/y(1); % Time-derivative for number concentraation of particles (#/m3)
            
            % Available fraction of crystallite surface area for secondary nucleation
            crystL = (m_k(4)/m_k(1))^(1/3); % m
            partL = crystL*sqrt(kV*m_k(1)/y(1)); % m
            if partL<crystL*a_r*2 % No secondary nucleation yet
                xA = 2/(2+a_r); % Only side faces of crystallites are available for secondary nucleation
            else
                xA = 4*crystL*partL*y(1)/kA/m_k(3); % Top, bottom, and intraparticle surfaces not available for secondary nucleation
            end
            
            % Critical size of secondary nuclei and true-catalytic secondary nucleation rate
            gammaEff = gamma-sigmaRel*gamma/2/(a_r+2); % Effective interfacial tension for secondary nucleation; J/m2
            AII = diffCoeff*sqrt((kB*T_K/gammaEff)^3/(3*pi*B))/monomerL^4/solventMolecVol; % Pre-exponential factor in secondary nucleation rate expression (#/(m2*s))
            LII = 2*kA*monomerVol*gammaEff/3/kV/kB/T_K/log(supersatRatio); % m
            JII = AII*(log(supersatRatio))^2*xA*kA*m_k(3)*exp(-B*gammaEff^3*monomerVol^2/kB^3/T_K^3/(log(supersatRatio))^2); % #/(m3*s)
            
            % DQMOM source term for nucleation (column vector with 2qN rows each corresponding to a moment order)
            sourceNucl = ( JI*LI.^(0:2*qN-1)' + JII*LII.^(0:2*qN-1)' ).*...
                10.^(9*(0:2*qN-1)');
            
            % Growth rate and DQMOM source term
            
            % % Uncomment for diffusion-controlled growth (may need larger timeScaleFactor like 1e+6)
            % effectivenessFactor = 0.1; % Crystal growth rate effectiveness factor defined in Sohnel and Garside's text
            % Gi = effectivenessFactor*2*kA*diffCoeff*molarVol_precSolid/3/kV./Li * cEqbrm * (supersatRatio^(1/nuPrecSolid)-1);
            
            % % Uncomment for integration-controlled growth
            Gi = kA*k_r*molarVol_precSolid*cEqbrm^g*...
               (supersatRatio^(1/nuPrecSolid)-1)^g/3/kV * ones(qN,1); % Integration-controlled growth rate
            
            % % Uncomment for automatically selected growth according to Nielsen's growth regime map criterion
            % Gi = min([2*kA*diffCoeff*molarVol_precSolid/3/kV./Li * cEqbrm * (supersatRatio^(1/nuPrecSolid)-1),...
            %    kA*k_r*molarVol_precSolid*cEqbrm^g*(supersatRatio^(1/nuPrecSolid)-1)^g/3/kV * ones(qN,1)],[],2);
            
            % % Uncomment for automatically selected growth per DD Harris MS. Thesis (technically strictly for g = 1)
            % Gi = 1 ./ ( 1./(2*kA*diffCoeff*molarVol_precSolid/3/kV./Li * cEqbrm * (supersatRatio^(1/nuPrecSolid)-1)) + ...
            %    1./(kA*k_r*molarVol_precSolid*cEqbrm^g*(supersatRatio^(1/nuPrecSolid)-1)^g/3/kV * ones(qN,1)) );
            
            A2 = k_Moments.*Li'.^(k_Moments-1); % Defined with Li in m (instead of Li_nm in nm)
            sourceGrowth = (A2*diag(wi)*Gi) .*10.^(9*(0:2*qN-1)');
            
            % Scaled overall source term
            sourceScaled = scaleMatrix*(sourceNucl+sourceGrowth+sourceVolChange);
            
            % dydt for weights and weighted abscissas from the solution of linear equations system
            dydt(2:2*qN+1) = A_scaled\sourceScaled; % Derivative for weights and weighted absiccases (wi*Li_nm)
            dydt(2:2+qN-1) = dydt(2:2+qN-1)/log(10)./wi; % Derivative of log10(wi)
            dydt(2+qN:2*qN+1) = dydt(2+qN:2*qN+1)/log(10)./wi./Li_nm; % Derivative for log10(wi*Li_nm)
            
            % dydt for elements for which we have mass balances
            dSolid_dt = 1e+3*kV*V_soln/molarVol_precSolid*...
                ( JI*LI^3 + JII*LII^3 + 3*sum(wi.*Gi.*Li.^2) ); % Rate of solid precipitation (mmol/s)
            dydt(2*qN+2:end) = 1e+3*element_inflowConc(elements_gasEquilFlag(1,:)==0)'*Q_Current*1000 - ...
                dSolid_dt*stoich_precSolid(elements_gasEquilFlag(1,:)==0)'; % 1000 converts mol/L to mol/m3
            
        end
        dydt = dydt/timeScaleFactor;
    end

end